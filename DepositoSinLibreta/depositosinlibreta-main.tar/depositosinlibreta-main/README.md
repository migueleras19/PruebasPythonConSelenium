# depositoSinLibreta

Carga de depositos en efectivo en el sistema fitbank desde un CSV, realizando capturas de pantalla para evidencia

# Instalar

1.- Instalar python linux

2.- Instalar Pip

3.- Instalar Selenium

4.- Descargar Driver Chorme y guardarlo a un nivel antes de la carpeta del proyecto
    http://10.17.32.39:8080/index.php/s/APCQ9aazRDb7zyZ

# Utilización

* El archivo "config.txt" contiene la url, usuario, contraseña y número de transacción a utilizar en el script
* El archivo CargaDatos.csv contiene el formato de las variables a enviar al script
* Para utlizar el script escribir el siguiente comando "**python depositoAhorro.py**" tiene que ser al nivel en donde se encuentra este archivo

**NOTA**: no se olvide de tener el driver de chorme descargado como lo indica el paso 4
